# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['core']

package_data = \
{'': ['*']}

install_requires = \
['aio-pika>=8.2.5,<9.0.0',
 'argparse>=1.4.0,<2.0.0',
 'fastapi>=0.88.0,<0.89.0',
 'minio>=7.1.12,<8.0.0',
 'pika>=1.3.1,<2.0.0',
 'pydantic>=1.10.2,<2.0.0',
 'pymongo>=4.3.3,<5.0.0',
 'python-dotenv>=0.21.0,<0.22.0',
 'sse-starlette>=1.2.1,<2.0.0',
 'tqdm>=4.64.1,<5.0.0',
 'uvicorn[standard]>=0.20.0,<0.21.0',
 'wget>=3.2,<4.0']

entry_points = \
{'console_scripts': ['api = core.api:main']}

setup_kwargs = {
    'name': 'dtcc-core',
    'version': '0.1.0',
    'description': 'Common Rest API, PubSub and database handlers for DTCC Platform',
    'long_description': '# DTCC Core\n\nCommon Rest API, PubSub and database handlers for DTCC Platform.\n\nThis project is part the\n[Digital Twin Platform (DTCC Platform)](https://gitlab.com/dtcc-platform)\ndeveloped at the\n[Digital Twin Cities Centre](https://dtcc.chalmers.se/)\nsupported by Sweden’s Innovation Agency Vinnova under Grant No. 2019-421 00041.\n\n## Documentation\n\n* [Introduction](./doc/introduction.md)\n* [Installation](./doc/installation.md)\n* [Usage](./doc/usage.md)\n* [Development](./doc/development.md)\n\n## Authors (in order of appearance)\n\n* [Vasilis Naserentin](https://www.chalmers.se/en/Staff/Pages/vasnas.aspx)\n* [Siddhartha Kasaraneni](https://chalmersindustriteknik.se/sv/medarbetare/siddhartha-kasaranemi/)\n* [Anders Logg](http://anders.logg.org)\n* [Dag Wästerberg](https://chalmersindustriteknik.se/sv/medarbetare/dag-wastberg/)\n\n## License\n\nDTCC Core is licensed under the\n[MIT license](https://opensource.org/licenses/MIT).\n\nCopyright is held by the individual authors as listed at the top of\neach source file.\n\n\n## API test\n\n- curl -X POST localhost:8090/tasks/generateTest/start\n- curl -X POST localhost:8090/tasks/generateCityModel/start\n- curl -X GET localhost:8090/tasks/generateTest/get-result\n\n## Poetry \n- install poetry: `curl -sSL https://install.python-poetry.org | python3 -`\n- create venv: `poetry shell`\n- activate venv: `source $(poetry env info --path)/bin/activate`\n- install libs: `poetry install`\n- Build and install as a library:\n    ```\n    poetry build\n    pip install dist/{wheel_file}.whl\n    ```\n- add poetry to path: `export  PATH="~/.local/bin:$PATH"`\n- Error "`Failed to unlock the collection!`": \n    - run -> `export PYTHON_KEYRING_BACKEND=keyring.backends.null.Keyring`',
    'author': 'sidkas',
    'author_email': 'sidkas@protonmail.ch',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'https://platform.dtcc.chalmers.se/',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
